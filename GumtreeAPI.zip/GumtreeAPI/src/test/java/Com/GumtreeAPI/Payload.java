package Com.GumtreeAPI;

public class Payload {
    public static String Userpayload(){
        String A="{\n" +
                "\"Title\":\"My Post Title\"\n" +
                "\"Post\":\"My Post Body\"\n" +
                "}";
        return A;
    }
}
